from setuptools import setup

setup(name='fixer',
      version='1.0',
      packages=['fixer'],
      url='#',
      zip_safe=False)
