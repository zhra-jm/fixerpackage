def get_rates():
    print('hi')